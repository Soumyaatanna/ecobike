package hcl.esg.ebike.application;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SecurityApp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security_app);
    }
}